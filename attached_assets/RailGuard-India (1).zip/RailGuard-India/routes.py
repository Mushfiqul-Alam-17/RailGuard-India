import json
import re
import qrcode
import io
import base64
import time
import logging
from flask import render_template, request, jsonify, redirect, url_for, flash
from app import app, db
from models import Complaint, Dispute, Zone, Seat, TrustID
from sms_service import process_incoming_sms, send_response_sms
from utils import analyze_complaint_risk, extract_train_number
from blockchain_utils import (
    generate_trust_id_hash, 
    encrypt_aadhaar, 
    decrypt_aadhaar, 
    trust_id_blockchain
)

# Configure logger
logger = logging.getLogger(__name__)

@app.route('/')
def index():
    """Landing page"""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """Main dashboard for demo"""
    complaints = Complaint.query.order_by(Complaint.timestamp.desc()).all()
    disputes = Dispute.query.order_by(Dispute.timestamp.desc()).all()
    zones = Zone.query.order_by(Zone.timestamp.desc()).all()
    seats = Seat.query.all()
    
    return render_template(
        'dashboard.html', 
        complaints=complaints, 
        disputes=disputes, 
        zones=zones,
        seats=seats
    )

@app.route('/zone_qr')
def zone_qr():
    """Page to generate QR codes for standing zones"""
    return render_template('zone_qr.html')

@app.route('/api/complaints', methods=['GET'])
def get_complaints():
    """API to get all complaints"""
    complaints = Complaint.query.order_by(Complaint.timestamp.desc()).all()
    return jsonify([complaint.to_dict() for complaint in complaints])

@app.route('/api/disputes', methods=['GET'])
def get_disputes():
    """API to get all disputes"""
    disputes = Dispute.query.order_by(Dispute.timestamp.desc()).all()
    return jsonify([dispute.to_dict() for dispute in disputes])

@app.route('/api/zones', methods=['GET'])
def get_zones():
    """API to get all standing zones"""
    zones = Zone.query.order_by(Zone.timestamp.desc()).all()
    return jsonify([zone.to_dict() for zone in zones])

@app.route('/api/seats', methods=['GET'])
def get_seats():
    """API to get all seats"""
    seats = Seat.query.all()
    return jsonify([seat.to_dict() for seat in seats])

@app.route('/api/sms/webhook', methods=['POST'])
def sms_webhook():
    """Webhook for receiving SMS messages via Twilio"""
    from_number = request.values.get('From', '')
    body = request.values.get('Body', '').strip()
    
    # Process the incoming SMS
    response_message = process_incoming_sms(from_number, body)
    
    # Return a TwiML response
    return f"""
    <?xml version="1.0" encoding="UTF-8"?>
    <Response>
        <Message>{response_message}</Message>
    </Response>
    """

@app.route('/api/generate_zone', methods=['POST'])
def generate_zone():
    """API to generate a standing zone QR code"""
    data = request.json
    phone = data.get('phone', '')
    coach = data.get('coach', '')
    zone = data.get('zone', '')
    
    if not phone or not coach or not zone:
        return jsonify({"error": "Missing required fields"}), 400
    
    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr_data = {
        "type": "standing_zone",
        "phone": phone,
        "coach": coach,
        "zone": zone
    }
    qr.add_data(json.dumps(qr_data))
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert QR code to base64 for storage and display
    buffered = io.BytesIO()
    img.save(buffered)
    qr_code_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
    
    # Save to database
    zone_entry = Zone(
        phone=phone,
        coach=coach,
        zone=zone,
        qr_code=qr_code_base64
    )
    db.session.add(zone_entry)
    db.session.commit()
    
    # Send SMS to the passenger
    message = f"Your standing zone has been assigned: Coach {coach}, Zone {zone}. Show this QR code to the TT."
    send_response_sms(phone, message)
    
    return jsonify({
        "success": True,
        "zone_id": zone_entry.id,
        "qr_code": qr_code_base64
    })

@app.route('/api/update_seat', methods=['POST'])
def update_seat():
    """API to update seat status (for demo reallocation)"""
    data = request.json
    coach = data.get('coach', '')
    seat_number = data.get('seat_number', '')
    status = data.get('status', '')
    assigned_to = data.get('assigned_to', None)
    
    if not coach or not seat_number or not status:
        return jsonify({"error": "Missing required fields"}), 400
    
    # Find or create the seat
    seat = Seat.query.filter_by(coach=coach, seat_number=seat_number).first()
    if not seat:
        seat = Seat(coach=coach, seat_number=seat_number)
    
    seat.status = status
    seat.assigned_to = assigned_to
    
    db.session.add(seat)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "seat": seat.to_dict()
    })

@app.route('/api/manual_complaint', methods=['POST'])
def manual_complaint():
    """API for manually adding a complaint (for demo purposes)"""
    data = request.json
    phone = data.get('phone', '')
    message = data.get('message', '')
    
    if not phone or not message:
        return jsonify({"error": "Missing required fields"}), 400
    
    # Extract train number if present in the message
    train_number = None
    train_match = re.search(r'Train\s+(\d+)', message, re.IGNORECASE)
    if train_match:
        train_number = train_match.group(1)
    
    # Analyze risk level
    risk_level = analyze_complaint_risk(message)
    
    # Create complaint
    complaint = Complaint(
        phone=phone,
        message=message,
        train_number=train_number,
        risk_level=risk_level
    )
    db.session.add(complaint)
    db.session.commit()
    
    # Send confirmation SMS
    confirmation_message = "Your complaint has been logged and is under review. Thank you for your feedback."
    send_response_sms(phone, confirmation_message)
    
    return jsonify({
        "success": True,
        "complaint": complaint.to_dict()
    })

@app.route('/api/manual_dispute', methods=['POST'])
def manual_dispute():
    """API for manually adding a dispute (for demo purposes)"""
    data = request.json
    phone = data.get('phone', '')
    fine_id = data.get('fine_id', '')
    
    if not phone or not fine_id:
        return jsonify({"error": "Missing required fields"}), 400
    
    # Create dispute
    dispute = Dispute(
        phone=phone,
        fine_id=fine_id
    )
    db.session.add(dispute)
    db.session.commit()
    
    # Send confirmation SMS
    confirmation_message = f"Your dispute for fine {fine_id} has been logged and is under review. Expect resolution within 24 hours."
    send_response_sms(phone, confirmation_message)
    
    return jsonify({
        "success": True,
        "dispute": dispute.to_dict()
    })

@app.route('/api/update_complaint_status', methods=['POST'])
def update_complaint_status():
    """API to update complaint status (for demo purposes)"""
    data = request.json
    complaint_id = data.get('complaint_id', '')
    status = data.get('status', '')
    
    if not complaint_id or not status:
        return jsonify({"error": "Missing required fields"}), 400
    
    complaint = Complaint.query.get(complaint_id)
    if not complaint:
        return jsonify({"error": "Complaint not found"}), 404
    
    complaint.status = status
    db.session.commit()
    
    return jsonify({
        "success": True,
        "complaint": complaint.to_dict()
    })

@app.route('/api/update_dispute_status', methods=['POST'])
def update_dispute_status():
    """API to update dispute status (for demo purposes)"""
    data = request.json
    dispute_id = data.get('dispute_id', '')
    status = data.get('status', '')
    
    if not dispute_id or not status:
        return jsonify({"error": "Missing required fields"}), 400
    
    dispute = Dispute.query.get(dispute_id)
    if not dispute:
        return jsonify({"error": "Dispute not found"}), 404
    
    dispute.status = status
    db.session.commit()
    
    return jsonify({
        "success": True,
        "dispute": dispute.to_dict()
    })

@app.route('/trust_id')
def trust_id_page():
    """Page for Trust ID registration and verification"""
    trust_ids = TrustID.query.order_by(TrustID.created_at.desc()).all()
    return render_template('trust_id.html', trust_ids=trust_ids)

@app.route('/api/trust_id', methods=['POST'])
def create_trust_id():
    """API to create a new Trust ID with blockchain-secured encryption and optional Aadhaar"""
    try:
        data = request.json
        name = data.get('name', '')
        phone = data.get('phone', '')
        aadhaar = data.get('aadhaar', None)  # Full Aadhaar number (optional)
        kiosk_mode = data.get('kiosk_mode', False)  # If registered via kiosk
        offline_mode = data.get('offline_mode', False)  # For offline registration
        
        if not name or not phone:
            return jsonify({"error": "Name and phone number are required"}), 400
        
        # Check if phone number already has a Trust ID
        existing_trust_id = TrustID.query.filter_by(phone=phone).first()
        if existing_trust_id:
            return jsonify({"error": "This phone number already has a Trust ID", 
                           "trust_id": existing_trust_id.trust_id}), 400
        
        # Generate secure Trust ID hash
        trust_id_hash = generate_trust_id_hash(
            name=name, 
            phone=phone, 
            aadhaar_last_4=aadhaar[-4:] if aadhaar else None
        )
        
        # Determine verification method
        verification_method = "phone"  # Default
        if aadhaar:
            verification_method = "aadhaar"
        elif kiosk_mode:
            verification_method = "kiosk"
        elif offline_mode:
            verification_method = "offline"
        
        # Create new Trust ID with blockchain security
        new_trust_id = TrustID(
            trust_id=trust_id_hash,
            name=name,
            phone=phone,
            is_verified=bool(aadhaar) or kiosk_mode,  # Auto-verify with Aadhaar or kiosk
            verification_method=verification_method
        )
        
        # If Aadhaar provided, encrypt it securely (never stored in plain text)
        if aadhaar:
            # Encrypt Aadhaar with strong encryption
            encrypted_data = encrypt_aadhaar(aadhaar)
            new_trust_id.encrypted_aadhaar = encrypted_data["encrypted_data"]
            new_trust_id.encryption_salt = encrypted_data["salt"]
            
            # Add to blockchain for immutable verification (NO actual Aadhaar data)
            block_data = {
                "trust_id": trust_id_hash,
                "verification_type": "aadhaar",
                "timestamp": time.time(),
                # DPDP Act & Aadhaar Act compliant: No actual Aadhaar data in blockchain
            }
            block = trust_id_blockchain.add_trust_id(block_data)
            new_trust_id.blockchain_hash = block.hash
            
            logger.info(f"Created Trust ID with Aadhaar verification: {trust_id_hash[:8]}...")
        
        # For kiosk mode registration (for those without smartphones)
        elif kiosk_mode:
            # Add to blockchain for KIOSK verification
            block_data = {
                "trust_id": trust_id_hash,
                "verification_type": "kiosk",
                "timestamp": time.time(),
            }
            block = trust_id_blockchain.add_trust_id(block_data)
            new_trust_id.blockchain_hash = block.hash
            
            logger.info(f"Created Trust ID with KIOSK verification: {trust_id_hash[:8]}...")
        
        # Save to database
        db.session.add(new_trust_id)
        db.session.commit()
        
        # Generate QR code for Trust ID (useful for offline verification)
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr_data = {
            "type": "trust_id",
            "id": trust_id_hash,
            "name": name,
            "phone_last4": phone[-4:],
            "verification": verification_method,
            "timestamp": time.time()
        }
        qr.add_data(json.dumps(qr_data))
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert QR code to base64 for display
        buffered = io.BytesIO()
        img.save(buffered)
        qr_code_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        # Send confirmation SMS (if not offline mode)
        if not offline_mode:
            message = (f"Your RailGuard Trust ID has been created: {trust_id_hash[:8]}... "
                      f"Verification: {verification_method.upper()}. "
                      f"Use this ID for all railway services.")
            send_response_sms(phone, message)
        
        return jsonify({
            "success": True,
            "trust_id": new_trust_id.to_dict(),
            "qr_code": qr_code_base64,
            "blockchain_verified": bool(new_trust_id.blockchain_hash)
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating Trust ID: {str(e)}")
        return jsonify({"error": f"Failed to create Trust ID: {str(e)}"}), 500

@app.route('/api/verify_trust_id', methods=['POST'])
def verify_trust_id():
    """API to verify a Trust ID with blockchain validation support and offline mode"""
    try:
        data = request.json
        trust_id_str = data.get('trust_id', '')
        verification_method = data.get('verification_method', 'phone')  # phone, aadhaar, kiosk, offline
        aadhaar = data.get('aadhaar', None)  # Only used if verification_method is 'aadhaar'
        kiosk_mode = data.get('kiosk_mode', False)  # For kiosk verification
        offline_mode = data.get('offline_mode', False)  # For offline verification
        
        if not trust_id_str:
            return jsonify({"error": "Trust ID is required"}), 400
        
        # Find Trust ID in database
        trust_id = TrustID.query.filter_by(trust_id=trust_id_str).first()
        if not trust_id:
            return jsonify({"error": "Trust ID not found"}), 404
        
        # Verify using blockchain for added security
        blockchain_verified = False
        blockchain_block = trust_id_blockchain.search_by_id(trust_id_str)
        
        if blockchain_block:
            blockchain_verified = True
            logger.info(f"Blockchain verification successful for Trust ID: {trust_id_str[:8]}...")
        
        # For Aadhaar verification - validate the encrypted Aadhaar
        if verification_method == 'aadhaar' and aadhaar and trust_id.encrypted_aadhaar:
            # Check if provided Aadhaar matches encrypted one
            # This would require government authorized software - demo only
            decrypted_aadhaar = decrypt_aadhaar(
                trust_id.encrypted_aadhaar, 
                trust_id.encryption_salt
            )
            
            if decrypted_aadhaar == aadhaar:
                trust_id.is_verified = True
                trust_id.verification_method = 'aadhaar'
                blockchain_verified = True
                logger.info("Aadhaar verification successful")
            else:
                logger.error("Aadhaar verification failed - mismatch")
                return jsonify({"error": "Aadhaar verification failed"}), 400
        
        # For kiosk verification (for those without smartphones/internet)
        elif verification_method == 'kiosk' or kiosk_mode:
            trust_id.is_verified = True
            trust_id.verification_method = 'kiosk'
            
            # Add to blockchain if not already there (for kiosk mode)
            if not blockchain_block:
                block_data = {
                    "trust_id": trust_id_str,
                    "verification_type": "kiosk",
                    "timestamp": time.time()
                }
                block = trust_id_blockchain.add_trust_id(block_data)
                trust_id.blockchain_hash = block.hash
                blockchain_verified = True
                
            logger.info(f"Kiosk verification successful for Trust ID: {trust_id_str[:8]}...")
        
        # For offline verification
        elif verification_method == 'offline' or offline_mode:
            trust_id.is_verified = True
            trust_id.verification_method = 'offline'
            
            # For offline mode, we still record in blockchain when connection is available
            if not blockchain_block:
                block_data = {
                    "trust_id": trust_id_str,
                    "verification_type": "offline",
                    "timestamp": time.time()
                }
                block = trust_id_blockchain.add_trust_id(block_data)
                trust_id.blockchain_hash = block.hash
                blockchain_verified = True
                
            logger.info(f"Offline verification recorded for Trust ID: {trust_id_str[:8]}...")
        
        # Standard phone verification
        else:
            trust_id.is_verified = True
            
            # Add to blockchain if not already there
            if not blockchain_block:
                block_data = {
                    "trust_id": trust_id_str,
                    "verification_type": "phone",
                    "timestamp": time.time()
                }
                block = trust_id_blockchain.add_trust_id(block_data)
                trust_id.blockchain_hash = block.hash
                blockchain_verified = True
                
            logger.info(f"Phone verification successful for Trust ID: {trust_id_str[:8]}...")
        
        # Save changes to database
        db.session.commit()
        
        # Send confirmation SMS (if not offline mode)
        if not offline_mode:
            message = (
                f"Your RailGuard Trust ID has been verified via {trust_id.verification_method}. "
                f"Blockchain secured: {'Yes' if blockchain_verified else 'Pending'}. "
                f"Thank you for helping create a corruption-free railway system."
            )
            send_response_sms(trust_id.phone, message)
        
        return jsonify({
            "success": True,
            "verification_method": trust_id.verification_method,
            "blockchain_verified": blockchain_verified,
            "trust_id": trust_id.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error verifying Trust ID: {str(e)}")
        return jsonify({"error": f"Failed to verify Trust ID: {str(e)}"}), 500

@app.route('/api/trust_ids', methods=['GET'])
def get_trust_ids():
    """API to get all Trust IDs"""
    trust_ids = TrustID.query.order_by(TrustID.created_at.desc()).all()
    return jsonify([t.to_dict() for t in trust_ids])

@app.route('/kiosk')
def kiosk_mode():
    """Offline kiosk mode interface for users without internet or mobile phones"""
    trust_ids = TrustID.query.filter_by(verification_method='kiosk').order_by(TrustID.created_at.desc()).all()
    return render_template('kiosk.html', trust_ids=trust_ids)

@app.route('/api/kiosk/register', methods=['POST'])
def kiosk_register():
    """API to register a user via offline kiosk"""
    try:
        data = request.json
        name = data.get('name', '')
        # For users without phones, we generate a virtual ID or use government ID
        virtual_id = data.get('virtual_id', f"KIOSK-{int(time.time())}")
        phone = data.get('phone', virtual_id)  # Use virtual ID if no phone
        aadhaar = data.get('aadhaar', None)  # Optional Aadhaar
        
        if not name:
            return jsonify({"error": "Name is required"}), 400
        
        # Generate Trust ID hash
        trust_id_hash = generate_trust_id_hash(
            name=name, 
            phone=phone, 
            aadhaar_last_4=aadhaar[-4:] if aadhaar else None
        )
        
        # Create new Trust ID with kiosk verification
        new_trust_id = TrustID(
            trust_id=trust_id_hash,
            name=name,
            phone=phone,
            is_verified=True,  # Auto-verify kiosk registrations
            verification_method='kiosk'
        )
        
        # If Aadhaar provided, encrypt it
        if aadhaar:
            encrypted_data = encrypt_aadhaar(aadhaar)
            new_trust_id.encrypted_aadhaar = encrypted_data["encrypted_data"]
            new_trust_id.encryption_salt = encrypted_data["salt"]
            
            # Add to blockchain for immutable verification
            block_data = {
                "trust_id": trust_id_hash,
                "verification_type": "kiosk_aadhaar",
                "timestamp": time.time()
            }
            block = trust_id_blockchain.add_trust_id(block_data)
            new_trust_id.blockchain_hash = block.hash
        else:
            # Add to blockchain as kiosk verification
            block_data = {
                "trust_id": trust_id_hash,
                "verification_type": "kiosk",
                "timestamp": time.time()
            }
            block = trust_id_blockchain.add_trust_id(block_data)
            new_trust_id.blockchain_hash = block.hash
        
        # Save to database
        db.session.add(new_trust_id)
        db.session.commit()
        
        # Generate QR code for Trust ID (essential for offline verification)
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr_data = {
            "type": "trust_id",
            "id": trust_id_hash,
            "name": name,
            "verification": "kiosk",
            "timestamp": time.time()
        }
        qr.add_data(json.dumps(qr_data))
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert QR code to base64 for display
        buffered = io.BytesIO()
        img.save(buffered)
        qr_code_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        logger.info(f"Kiosk registration successful: {trust_id_hash[:8]}...")
        
        return jsonify({
            "success": True,
            "trust_id": new_trust_id.to_dict(),
            "qr_code": qr_code_base64,
            "blockchain_verified": True,
            "message": "Please print or save your QR code for railway travel identification"
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error in kiosk registration: {str(e)}")
        return jsonify({"error": f"Failed to register: {str(e)}"}), 500
        
@app.route('/api/offline/sync', methods=['POST'])
def offline_sync():
    """API to sync offline Trust IDs to blockchain when connection is available"""
    try:
        data = request.json
        offline_data = data.get('offline_data', [])
        
        if not offline_data:
            return jsonify({"error": "No offline data provided"}), 400
        
        synced_ids = []
        for item in offline_data:
            trust_id_str = item.get('trust_id')
            verification_type = item.get('verification_type', 'offline')
            
            # Check if Trust ID exists
            trust_id = TrustID.query.filter_by(trust_id=trust_id_str).first()
            if not trust_id:
                continue  # Skip if not found
                
            # Add to blockchain if not already there
            blockchain_block = trust_id_blockchain.search_by_id(trust_id_str)
            if not blockchain_block:
                block_data = {
                    "trust_id": trust_id_str,
                    "verification_type": verification_type,
                    "timestamp": time.time(),
                    "synced_from_offline": True
                }
                block = trust_id_blockchain.add_trust_id(block_data)
                trust_id.blockchain_hash = block.hash
                
                synced_ids.append({
                    "trust_id": trust_id_str,
                    "blockchain_hash": block.hash
                })
                
        db.session.commit()
        logger.info(f"Synced {len(synced_ids)} offline Trust IDs to blockchain")
        
        return jsonify({
            "success": True,
            "synced_count": len(synced_ids),
            "synced_ids": synced_ids
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error syncing offline data: {str(e)}")
        return jsonify({"error": f"Failed to sync offline data: {str(e)}"}), 500
