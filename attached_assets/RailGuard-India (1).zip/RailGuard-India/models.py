from datetime import datetime
import uuid
from app import db

class Complaint(db.Model):
    """Model for passenger complaints about TTs"""
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=False)
    train_number = db.Column(db.String(10), nullable=True)
    risk_level = db.Column(db.String(20), default="Normal")  # Normal, Medium, High
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Under Review")  # Under Review, Resolved, Dismissed
    
    def __repr__(self):
        return f"<Complaint {self.id}: {self.message[:30]}...>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "phone": self.phone[-4:].rjust(10, 'X'),  # Anonymized phone
            "message": self.message,
            "train_number": self.train_number,
            "risk_level": self.risk_level,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "status": self.status
        }

class Dispute(db.Model):
    """Model for fine disputes"""
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), nullable=False)
    fine_id = db.Column(db.String(20), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Under Review")  # Under Review, Resolved, Dismissed
    
    def __repr__(self):
        return f"<Dispute {self.id}: Fine {self.fine_id}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "phone": self.phone[-4:].rjust(10, 'X'),  # Anonymized phone
            "fine_id": self.fine_id,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "status": self.status
        }

class Zone(db.Model):
    """Model for standing passenger zones"""
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), nullable=False)
    coach = db.Column(db.String(10), nullable=False)
    zone = db.Column(db.String(5), nullable=False)
    qr_code = db.Column(db.Text, nullable=True)  # Store QR code as base64 or URL
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<Zone {self.id}: Coach {self.coach}, Zone {self.zone}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "phone": self.phone[-4:].rjust(10, 'X'),  # Anonymized phone
            "coach": self.coach,
            "zone": self.zone,
            "qr_code": self.qr_code,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        }

class Seat(db.Model):
    """Model for seats (for demo reallocation)"""
    id = db.Column(db.Integer, primary_key=True)
    coach = db.Column(db.String(10), nullable=False)
    seat_number = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(20), default="Occupied")  # Occupied, Vacant, Reallocated
    assigned_to = db.Column(db.String(50), nullable=True)  # Person's name for demo
    
    def __repr__(self):
        return f"<Seat {self.id}: Coach {self.coach}, Seat {self.seat_number}, Status: {self.status}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "coach": self.coach,
            "seat_number": self.seat_number,
            "status": self.status,
            "assigned_to": self.assigned_to
        }

class TrustID(db.Model):
    """Model for the Trust ID system (Aadhaar-optional, blockchain-secured)"""
    id = db.Column(db.Integer, primary_key=True)
    trust_id = db.Column(db.String(64), unique=True)  # SHA-256 hash is 64 chars
    phone = db.Column(db.String(20), nullable=False, unique=True)
    name = db.Column(db.String(100), nullable=False)
    encrypted_aadhaar = db.Column(db.Text, nullable=True)  # Encrypted full Aadhaar if provided
    encryption_salt = db.Column(db.Text, nullable=True)  # Salt for encryption
    blockchain_hash = db.Column(db.String(64), nullable=True)  # Hash from blockchain
    is_verified = db.Column(db.Boolean, default=False)
    verification_method = db.Column(db.String(20), default="phone")  # phone, aadhaar, kiosk, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<TrustID {self.trust_id}: {self.name}>"
    
    def to_dict(self):
        return {
            "trust_id": self.trust_id,
            "phone": self.phone[-4:].rjust(10, 'X'),  # Anonymized phone number
            "name": self.name,
            "has_aadhaar": bool(self.encrypted_aadhaar),  # Don't expose if they used Aadhaar
            "is_verified": self.is_verified,
            "verification_method": self.verification_method,
            "blockchain_verified": bool(self.blockchain_hash),
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M:%S")
        }
        
    @property
    def aadhaar_verified(self):
        """Check if this Trust ID was verified with Aadhaar"""
        return self.verification_method == "aadhaar" and self.is_verified
