import re
from config import RISK_KEYWORDS

def analyze_complaint_risk(message):
    """
    Analyze complaint message for risk keywords to flag potential TT fraud
    This simulates the AI Auto-Fraud Watchdog for the hackathon
    
    Args:
        message (str): The complaint message text
        
    Returns:
        str: Risk level (High, Medium, Normal)
    """
    message = message.lower()
    
    # Check for high risk keywords
    for keyword in RISK_KEYWORDS["high"]:
        if keyword.lower() in message:
            return "High Risk"
    
    # Check for medium risk keywords
    for keyword in RISK_KEYWORDS["medium"]:
        if keyword.lower() in message:
            return "Medium Risk"
    
    # Default risk level
    return "Normal"

def extract_train_number(message):
    """
    Extract train number from message if present
    
    Args:
        message (str): The message to parse
        
    Returns:
        str or None: The train number if found, None otherwise
    """
    train_match = re.search(r'Train\s+(\d+)', message, re.IGNORECASE)
    if train_match:
        return train_match.group(1)
    
    # Look for just numbers that might be train numbers
    num_match = re.search(r'\b\d{5}\b', message)
    if num_match:
        return num_match.group(0)
    
    return None

def format_phone_number(phone):
    """
    Format and anonymize phone number for display
    
    Args:
        phone (str): Raw phone number
        
    Returns:
        str: Anonymized phone number (e.g., XXXXXX1234)
    """
    if not phone:
        return "Unknown"
    
    # Keep only the last 4 digits, mask the rest
    return phone[-4:].rjust(10, 'X')

def is_fine_dispute(message):
    """
    Check if a message is a fine dispute
    
    Args:
        message (str): The message to check
        
    Returns:
        bool: True if message appears to be a fine dispute
    """
    # Check for keywords like "FINE" followed by numbers
    fine_match = re.search(r'FINE\s*(\d+)', message, re.IGNORECASE)
    
    # Also check for format like "Dispute FINE123"
    dispute_match = re.search(r'Dispute\s+FINE\s*(\d+)', message, re.IGNORECASE)
    
    return bool(fine_match or dispute_match)

def extract_fine_id(message):
    """
    Extract fine ID from a dispute message
    
    Args:
        message (str): The message containing a fine ID
        
    Returns:
        str or None: The fine ID if found, None otherwise
    """
    # Check for "FINE" followed by numbers
    fine_match = re.search(r'FINE\s*(\d+)', message, re.IGNORECASE)
    if fine_match:
        return f"FINE{fine_match.group(1)}"
    
    # Check for alphanumeric fine IDs
    id_match = re.search(r'\b([A-Z0-9]{6,10})\b', message)
    if id_match:
        return id_match.group(1)
    
    return None
