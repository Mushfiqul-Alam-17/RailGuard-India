import os

# Twilio Configuration
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER", "")

# Application Configuration
DEBUG = True
SECRET_KEY = os.environ.get("SESSION_SECRET", "railguard-secret-key")
SQLALCHEMY_DATABASE_URI = "sqlite:///railguard.db"
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Risk Keywords for Auto-Fraud Watchdog
RISK_KEYWORDS = {
    "high": ["bribe", "cash", "money", "no receipt", "illegal", "threatened", "force", "corrupt"],
    "medium": ["fine", "fee", "extra", "bad behavior", "rude", "shout", "aggressive"]
}
