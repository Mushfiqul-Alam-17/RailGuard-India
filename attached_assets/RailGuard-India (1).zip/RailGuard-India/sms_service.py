import os
import re
from twilio.rest import Client
from app import db
from models import Complaint, Dispute
from utils import analyze_complaint_risk, extract_train_number, is_fine_dispute, extract_fine_id
import logging

# Configure logger
logger = logging.getLogger(__name__)

# Twilio configuration
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "AC03d9cde5c523a31d210ff89b1d5d9cd9")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "ce4ca3ed8466174d5c229bb17476316e") 
TWILIO_PHONE_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER", "+14155238886")  # Using a default Twilio test number

# Initialize Twilio client if credentials are available
twilio_client = None
if TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
    try:
        twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        logger.info("Twilio client initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize Twilio client: {e}")
        logger.warning("SMS functionality will be simulated.")
else:
    logger.warning("Twilio credentials not found. SMS functionality will be simulated.")

def send_response_sms(to_phone, message):
    """
    Send an SMS response to a passenger
    
    Args:
        to_phone (str): Recipient's phone number
        message (str): Message to send
        
    Returns:
        bool: True if message was sent, False otherwise
    """
    if not twilio_client:
        logger.info(f"SMS would be sent to {to_phone}: {message}")
        return False
    
    try:
        message = twilio_client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=to_phone
        )
        logger.info(f"SMS sent to {to_phone} with SID: {message.sid}")
        return True
    except Exception as e:
        logger.error(f"Failed to send SMS to {to_phone}: {e}")
        return False

def process_incoming_sms(from_number, message):
    """
    Process incoming SMS messages and take appropriate action
    
    Args:
        from_number (str): Sender's phone number
        message (str): SMS message content
        
    Returns:
        str: Response message to be sent back
    """
    logger.info(f"Processing incoming SMS from {from_number}: {message}")
    
    # Check if this is a fine dispute
    if is_fine_dispute(message):
        fine_id = extract_fine_id(message)
        if fine_id:
            # Create a dispute record
            dispute = Dispute(
                phone=from_number,
                fine_id=fine_id
            )
            db.session.add(dispute)
            db.session.commit()
            logger.info(f"Fine dispute created for {fine_id}")
            return f"Your dispute for fine {fine_id} has been logged and is under review. Expect resolution within 24 hours."
    
    # Otherwise, treat as a complaint
    train_number = extract_train_number(message)
    risk_level = analyze_complaint_risk(message)
    
    # Create complaint record
    complaint = Complaint(
        phone=from_number,
        message=message,
        train_number=train_number,
        risk_level=risk_level
    )
    db.session.add(complaint)
    db.session.commit()
    logger.info(f"Complaint created with ID {complaint.id}, risk level: {risk_level}")
    
    # Return confirmation message
    return "Your complaint has been logged and is under review. Thank you for your feedback."
