// RailGuard India - Dashboard JavaScript

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Set up real-time updates using polling
    setInterval(refreshDashboardData, 5000);
    
    // Initialize event listeners
    setupEventListeners();
    
    // Initialize charts
    initializeCharts();
    
    // First data load
    refreshDashboardData();
});

// Setup event listeners for interactive elements
function setupEventListeners() {
    // Manual complaint form submission
    const complaintForm = document.getElementById('complaintForm');
    if (complaintForm) {
        complaintForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitManualComplaint();
        });
    }
    
    // Manual dispute form submission
    const disputeForm = document.getElementById('disputeForm');
    if (disputeForm) {
        disputeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitManualDispute();
        });
    }
    
    // Seat update form
    const seatForm = document.getElementById('seatForm');
    if (seatForm) {
        seatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updateSeatStatus();
        });
    }
    
    // Status update buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('update-complaint-status')) {
            const complaintId = e.target.getAttribute('data-id');
            const status = e.target.getAttribute('data-status');
            updateComplaintStatus(complaintId, status);
        }
        
        if (e.target.classList.contains('update-dispute-status')) {
            const disputeId = e.target.getAttribute('data-id');
            const status = e.target.getAttribute('data-status');
            updateDisputeStatus(disputeId, status);
        }
    });
}

// Refresh dashboard data via API calls
function refreshDashboardData() {
    // Fetch latest complaints
    fetch('/api/complaints')
        .then(response => response.json())
        .then(data => {
            updateComplaintsList(data);
            updateComplaintStats(data);
        })
        .catch(error => console.error('Error fetching complaints:', error));
    
    // Fetch latest disputes
    fetch('/api/disputes')
        .then(response => response.json())
        .then(data => {
            updateDisputesList(data);
        })
        .catch(error => console.error('Error fetching disputes:', error));
    
    // Fetch zones
    fetch('/api/zones')
        .then(response => response.json())
        .then(data => {
            updateZonesList(data);
        })
        .catch(error => console.error('Error fetching zones:', error));
    
    // Fetch seats
    fetch('/api/seats')
        .then(response => response.json())
        .then(data => {
            updateSeatsList(data);
        })
        .catch(error => console.error('Error fetching seats:', error));
}

// Update the complaints list in the UI
function updateComplaintsList(complaints) {
    const complaintsContainer = document.getElementById('complaintsList');
    if (!complaintsContainer) return;
    
    // Store existing complaint IDs to identify new ones
    const existingIds = Array.from(complaintsContainer.querySelectorAll('.complaint-item'))
        .map(item => item.getAttribute('data-id'));
    
    // Clear and rebuild list
    complaintsContainer.innerHTML = '';
    
    if (complaints.length === 0) {
        complaintsContainer.innerHTML = '<div class="alert alert-info">No complaints reported yet.</div>';
        return;
    }
    
    complaints.forEach(complaint => {
        const isNew = !existingIds.includes(complaint.id.toString());
        const riskClass = complaint.risk_level.toLowerCase().includes('high') ? 'risk-high' : 
                         complaint.risk_level.toLowerCase().includes('medium') ? 'risk-medium' : 'risk-normal';
        
        const complaintHtml = `
            <div class="complaint-item ${riskClass} ${isNew ? 'highlight' : ''}" data-id="${complaint.id}">
                <div class="d-flex justify-content-between">
                    <strong>${complaint.risk_level}</strong>
                    <span class="complaint-phone">${complaint.phone}</span>
                </div>
                <p>${complaint.message}</p>
                <div class="d-flex justify-content-between">
                    <span class="badge ${complaint.status === 'Under Review' ? 'bg-warning' : 'bg-success'}">${complaint.status}</span>
                    <span class="complaint-time">${complaint.timestamp}</span>
                </div>
                <div class="mt-2">
                    <button class="btn btn-sm btn-success update-complaint-status" data-id="${complaint.id}" data-status="Resolved">
                        Mark Resolved
                    </button>
                    <button class="btn btn-sm btn-danger update-complaint-status" data-id="${complaint.id}" data-status="Dismissed">
                        Dismiss
                    </button>
                </div>
            </div>
        `;
        
        complaintsContainer.innerHTML += complaintHtml;
    });
}

// Update dispute list in the UI
function updateDisputesList(disputes) {
    const disputesContainer = document.getElementById('disputesList');
    if (!disputesContainer) return;
    
    // Store existing dispute IDs to identify new ones
    const existingIds = Array.from(disputesContainer.querySelectorAll('.dispute-item'))
        .map(item => item.getAttribute('data-id'));
    
    // Clear and rebuild list
    disputesContainer.innerHTML = '';
    
    if (disputes.length === 0) {
        disputesContainer.innerHTML = '<div class="alert alert-info">No disputes reported yet.</div>';
        return;
    }
    
    disputes.forEach(dispute => {
        const isNew = !existingIds.includes(dispute.id.toString());
        
        const disputeHtml = `
            <div class="dispute-item ${isNew ? 'highlight' : ''}" data-id="${dispute.id}">
                <div class="d-flex justify-content-between">
                    <strong>Fine ID: ${dispute.fine_id}</strong>
                    <span class="dispute-phone">${dispute.phone}</span>
                </div>
                <div class="d-flex justify-content-between mt-2">
                    <span class="badge ${dispute.status === 'Under Review' ? 'bg-warning' : 'bg-success'}">${dispute.status}</span>
                    <span class="dispute-time">${dispute.timestamp}</span>
                </div>
                <div class="mt-2">
                    <button class="btn btn-sm btn-success update-dispute-status" data-id="${dispute.id}" data-status="Resolved">
                        Mark Resolved
                    </button>
                    <button class="btn btn-sm btn-danger update-dispute-status" data-id="${dispute.id}" data-status="Dismissed">
                        Dismiss
                    </button>
                </div>
            </div>
        `;
        
        disputesContainer.innerHTML += disputeHtml;
    });
}

// Update zones list in the UI
function updateZonesList(zones) {
    const zonesContainer = document.getElementById('zonesList');
    if (!zonesContainer) return;
    
    // Clear and rebuild list
    zonesContainer.innerHTML = '';
    
    if (zones.length === 0) {
        zonesContainer.innerHTML = '<div class="alert alert-info">No standing zones assigned yet.</div>';
        return;
    }
    
    zones.forEach(zone => {
        const zoneHtml = `
            <div class="zone-item">
                <div class="d-flex justify-content-between">
                    <strong>Coach ${zone.coach}, Zone ${zone.zone}</strong>
                    <span class="zone-phone">${zone.phone}</span>
                </div>
                <div class="text-center my-2">
                    <img src="data:image/png;base64,${zone.qr_code}" alt="QR Code" class="img-fluid" style="max-width: 150px;">
                </div>
                <div class="text-center">
                    <span class="zone-time">${zone.timestamp}</span>
                </div>
            </div>
        `;
        
        zonesContainer.innerHTML += zoneHtml;
    });
}

// Update seats list in the UI
function updateSeatsList(seats) {
    const seatsContainer = document.getElementById('seatsList');
    if (!seatsContainer) return;
    
    // Clear and rebuild list
    seatsContainer.innerHTML = '';
    
    if (seats.length === 0) {
        seatsContainer.innerHTML = '<div class="alert alert-info">No seats available for reallocation.</div>';
        return;
    }
    
    seats.forEach(seat => {
        const statusClass = seat.status === 'Vacant' ? 'seat-vacant' : 
                          seat.status === 'Reallocated' ? 'seat-reallocated' : 'seat-occupied';
        
        const seatHtml = `
            <div class="col-md-4 mb-3">
                <div class="card ${statusClass}">
                    <div class="card-body text-center">
                        <h5 class="card-title">Coach ${seat.coach}, Seat ${seat.seat_number}</h5>
                        <p class="card-text">Status: ${seat.status}</p>
                        ${seat.assigned_to ? `<p class="card-text">Assigned to: ${seat.assigned_to}</p>` : ''}
                    </div>
                </div>
            </div>
        `;
        
        seatsContainer.innerHTML += seatHtml;
    });
}

// Submit a manual complaint (for demo)
function submitManualComplaint() {
    const phone = document.getElementById('complaintPhone').value;
    const message = document.getElementById('complaintMessage').value;
    
    if (!phone || !message) {
        alert('Please fill in all fields');
        return;
    }
    
    // Send API request
    fetch('/api/manual_complaint', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            phone: phone,
            message: message
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Clear form
            document.getElementById('complaintPhone').value = '';
            document.getElementById('complaintMessage').value = '';
            
            // Show success message
            alert('Complaint submitted successfully');
            
            // Refresh data
            refreshDashboardData();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error submitting complaint:', error);
        alert('Failed to submit complaint');
    });
}

// Submit a manual dispute (for demo)
function submitManualDispute() {
    const phone = document.getElementById('disputePhone').value;
    const fineId = document.getElementById('disputeFineId').value;
    
    if (!phone || !fineId) {
        alert('Please fill in all fields');
        return;
    }
    
    // Send API request
    fetch('/api/manual_dispute', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            phone: phone,
            fine_id: fineId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Clear form
            document.getElementById('disputePhone').value = '';
            document.getElementById('disputeFineId').value = '';
            
            // Show success message
            alert('Dispute submitted successfully');
            
            // Refresh data
            refreshDashboardData();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error submitting dispute:', error);
        alert('Failed to submit dispute');
    });
}

// Update seat status (for demo reallocation)
function updateSeatStatus() {
    const coach = document.getElementById('seatCoach').value;
    const seatNumber = document.getElementById('seatNumber').value;
    const status = document.getElementById('seatStatus').value;
    const assignedTo = document.getElementById('assignedTo').value;
    
    if (!coach || !seatNumber || !status) {
        alert('Please fill in required fields');
        return;
    }
    
    // Send API request
    fetch('/api/update_seat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            coach: coach,
            seat_number: seatNumber,
            status: status,
            assigned_to: assignedTo
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Clear form
            document.getElementById('seatCoach').value = '';
            document.getElementById('seatNumber').value = '';
            document.getElementById('assignedTo').value = '';
            
            // Show success message
            alert('Seat status updated successfully');
            
            // Refresh data
            refreshDashboardData();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error updating seat status:', error);
        alert('Failed to update seat status');
    });
}

// Update complaint status
function updateComplaintStatus(complaintId, status) {
    fetch('/api/update_complaint_status', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            complaint_id: complaintId,
            status: status
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            refreshDashboardData();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error updating complaint status:', error);
        alert('Failed to update complaint status');
    });
}

// Update dispute status
function updateDisputeStatus(disputeId, status) {
    fetch('/api/update_dispute_status', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            dispute_id: disputeId,
            status: status
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            refreshDashboardData();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error updating dispute status:', error);
        alert('Failed to update dispute status');
    });
}

// Initialize charts for dashboard statistics
function initializeCharts() {
    const complaintsCtx = document.getElementById('complaintsChart');
    if (complaintsCtx) {
        window.complaintsChart = new Chart(complaintsCtx, {
            type: 'pie',
            data: {
                labels: ['High Risk', 'Medium Risk', 'Normal'],
                datasets: [{
                    data: [0, 0, 0],
                    backgroundColor: [
                        '#e74c3c',  // red
                        '#f39c12',  // orange
                        '#2ecc71'   // green
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
}

// Update complaint statistics and chart
function updateComplaintStats(complaints) {
    const highRisk = complaints.filter(c => c.risk_level.toLowerCase().includes('high')).length;
    const mediumRisk = complaints.filter(c => c.risk_level.toLowerCase().includes('medium')).length;
    const normal = complaints.filter(c => c.risk_level.toLowerCase().includes('normal')).length;
    
    // Update statistics display
    const statsContainer = document.getElementById('complaintStats');
    if (statsContainer) {
        statsContainer.innerHTML = `
            <div class="col-md-4">
                <div class="alert alert-danger text-center">
                    <h3>${highRisk}</h3>
                    <p>High Risk</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="alert alert-warning text-center">
                    <h3>${mediumRisk}</h3>
                    <p>Medium Risk</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="alert alert-success text-center">
                    <h3>${normal}</h3>
                    <p>Normal</p>
                </div>
            </div>
        `;
    }
    
    // Update chart if available
    if (window.complaintsChart) {
        window.complaintsChart.data.datasets[0].data = [highRisk, mediumRisk, normal];
        window.complaintsChart.update();
    }
}
