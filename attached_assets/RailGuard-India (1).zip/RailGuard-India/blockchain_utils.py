import hashlib
import json
import time
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os
import logging

# Configure logger
logger = logging.getLogger(__name__)

# Secret key for symmetric encryption (in production, use env variables)
ENCRYPTION_KEY = os.environ.get("ENCRYPTION_KEY", "railguard_secure_key_2025")

class Block:
    """A single block in the Trust ID blockchain"""
    def __init__(self, index, timestamp, data, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.calculate_hash()
    
    def calculate_hash(self):
        """Calculate a SHA-256 hash of the block"""
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "data": self.data,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce
        }, sort_keys=True).encode()
        
        return hashlib.sha256(block_string).hexdigest()
    
    def mine_block(self, difficulty=2):
        """Mine a block with a specific difficulty (number of leading zeros)"""
        while self.hash[:difficulty] != '0' * difficulty:
            self.nonce += 1
            self.hash = self.calculate_hash()
        
        logger.info(f"Block mined: {self.hash}")
        return self.hash
    
    def to_dict(self):
        """Convert block to dictionary for JSON serialization"""
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "data": self.data,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
            "hash": self.hash
        }

class TrustIDBlockchain:
    """Simplified blockchain for Trust ID management"""
    def __init__(self):
        self.chain = [self.create_genesis_block()]
        self.difficulty = 2  # Difficulty for mining (in production, adjust based on hardware)
    
    def create_genesis_block(self):
        """Create the first block in the chain"""
        return Block(0, time.time(), {"message": "RailGuard India Genesis Block - Trust ID System"}, "0")
    
    def get_latest_block(self):
        """Get the most recent block in the chain"""
        return self.chain[-1]
    
    def add_trust_id(self, trust_id_data):
        """Add a new Trust ID to the blockchain"""
        index = len(self.chain)
        timestamp = time.time()
        previous_hash = self.get_latest_block().hash
        
        # Create and mine new block
        new_block = Block(index, timestamp, trust_id_data, previous_hash)
        new_block.mine_block(self.difficulty)
        
        # Add block to chain
        self.chain.append(new_block)
        
        logger.info(f"Added Trust ID block: {new_block.hash}")
        return new_block
    
    def is_chain_valid(self):
        """Validate the integrity of the blockchain"""
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i - 1]
            
            # Check if current hash is correctly calculated
            if current_block.hash != current_block.calculate_hash():
                return False
            
            # Check if block points to correct previous hash
            if current_block.previous_hash != previous_block.hash:
                return False
        
        return True
    
    def search_by_id(self, trust_id):
        """Search for a Trust ID in the blockchain"""
        for block in self.chain[1:]:  # Skip genesis block
            if "trust_id" in block.data and block.data["trust_id"] == trust_id:
                return block
        
        return None
    
    def to_json(self):
        """Convert blockchain to JSON for storage"""
        chain_data = []
        for block in self.chain:
            chain_data.append(block.to_dict())
        
        return json.dumps({"chain": chain_data})

def encrypt_aadhaar(aadhaar_number, salt=None):
    """
    Encrypt an Aadhaar number for secure storage
    
    Args:
        aadhaar_number (str): The Aadhaar number to encrypt
        salt (bytes, optional): Salt for key derivation
        
    Returns:
        dict: A dictionary containing the encrypted data and salt
    """
    if not salt:
        salt = os.urandom(16)
    
    # Convert the encryption key to bytes
    key_bytes = ENCRYPTION_KEY.encode()
    
    # Generate a key using PBKDF2
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(key_bytes))
    
    # Create a Fernet cipher with the derived key
    cipher = Fernet(key)
    
    # Encrypt the Aadhaar number
    encrypted_data = cipher.encrypt(aadhaar_number.encode())
    
    return {
        "encrypted_data": base64.b64encode(encrypted_data).decode('utf-8'),
        "salt": base64.b64encode(salt).decode('utf-8')
    }

def decrypt_aadhaar(encrypted_data, salt):
    """
    Decrypt an encrypted Aadhaar number
    
    Args:
        encrypted_data (str): Base64-encoded encrypted data
        salt (str): Base64-encoded salt used for encryption
        
    Returns:
        str or None: The decrypted Aadhaar number or None if decryption fails
    """
    try:
        # Convert the encryption key to bytes
        key_bytes = ENCRYPTION_KEY.encode()
        
        # Convert base64 data to bytes
        encrypted_bytes = base64.b64decode(encrypted_data)
        salt_bytes = base64.b64decode(salt)
        
        # Generate a key using PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt_bytes,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(key_bytes))
        
        # Create a Fernet cipher with the derived key
        cipher = Fernet(key)
        
        # Decrypt the data
        decrypted_data = cipher.decrypt(encrypted_bytes)
        
        return decrypted_data.decode('utf-8')
    except Exception as e:
        logger.error(f"Decryption failed: {e}")
        return None

def generate_trust_id_hash(name, phone, aadhaar_last_4=None):
    """
    Generate a secure hash for Trust ID that doesn't expose original data
    
    Args:
        name (str): User's name
        phone (str): User's phone number
        aadhaar_last_4 (str, optional): Last 4 digits of Aadhaar (optional)
        
    Returns:
        str: A unique Trust ID hash
    """
    # Create a string combining all data
    data_string = f"{name}|{phone}"
    if aadhaar_last_4:
        data_string += f"|{aadhaar_last_4}"
    
    # Add a timestamp for uniqueness
    data_string += f"|{time.time()}"
    
    # Hash the data using SHA-256
    return hashlib.sha256(data_string.encode()).hexdigest()

# Initialize global blockchain for Trust IDs
trust_id_blockchain = TrustIDBlockchain()