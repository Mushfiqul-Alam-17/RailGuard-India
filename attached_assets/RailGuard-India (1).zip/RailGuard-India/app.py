import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "railguard-secret-key")

# Configure PostgreSQL database
db_url = os.environ.get("DATABASE_URL", "postgresql://neondb_owner:npg_EzrdsCA9Z0iS@ep-patient-mud-a5k15fh6.us-east-2.aws.neon.tech/neondb?sslmode=require")
# Print database URL for debugging
print(f"Database URL: {db_url}")
app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True
}

# Initialize database
db = SQLAlchemy(app)

# Import routes after app and db are initialized to avoid circular imports
from routes import *

# Create database tables
with app.app_context():
    db.create_all()
    logger.info("Database tables created")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
